Segue imagens do projeto em execução:


![WhatsApp Image 2025-05-10 at 12 02 18](https://github.com/user-attachments/assets/640cb0db-219d-4163-ad59-e15f39e8f425)
![WhatsApp Image 2025-05-10 at 12 02 06](https://github.com/user-attachments/assets/3ca937a6-00df-434e-a0b7-eb2975d87d68)
